use myadvisortest;
select * from students
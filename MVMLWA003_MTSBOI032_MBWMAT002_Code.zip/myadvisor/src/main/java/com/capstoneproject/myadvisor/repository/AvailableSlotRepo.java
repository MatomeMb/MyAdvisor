package com.capstoneproject.myadvisor.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.capstoneproject.myadvisor.model.AvailableSlot;

@Repository
public interface AvailableSlotRepo extends JpaRepository<AvailableSlot, Integer> {
    List<AvailableSlot> findByAdvisorEmail(String advisorEmail);   
}

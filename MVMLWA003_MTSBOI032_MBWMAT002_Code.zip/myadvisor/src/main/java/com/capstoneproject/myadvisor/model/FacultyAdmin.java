package com.capstoneproject.myadvisor.model;

public class FacultyAdmin extends User{

}

package com.capstoneproject.myadvisor.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capstoneproject.myadvisor.model.User;
import com.capstoneproject.myadvisor.repository.UserRepo;
@Service
public class UserService {

    @Autowired
    private UserRepo userRepo;

    public List<User> getAllUsers() {
        return userRepo.findAll();
    }

    public void saveUser(User user){
        userRepo.save(user);
    }
}
package com.capstoneproject.myadvisor.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import com.capstoneproject.myadvisor.model.User;
import com.capstoneproject.myadvisor.service.UserService;

@Controller
public class SystemAdminController {
    
    @Autowired
    private UserService userService;

    @GetMapping("/systemAdminPage")
    public String systemAdminPage(Model model) {
        List<User> users = userService.getAllUsers();

        model.addAttribute("users", users);
        model.addAttribute("user", new User());
        return "systemAdminPage";
    }

    
}
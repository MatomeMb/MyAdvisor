package com.capstoneproject.myadvisor.model;

public class Faculty {
    private String Department;
    private String Degrees;
    private String Courses;
    
}

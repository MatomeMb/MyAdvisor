package com.capstoneproject.myadvisor.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Inheritance;
import jakarta.persistence.InheritanceType;
import jakarta.persistence.Table;

@Entity
@Table(name="USERS")
@Inheritance(strategy=InheritanceType.JOINED)
public class User {

    @Id
   // @Column(name="email")
    private String email;

    @Column(name="password")
    private String password;

    @Column(name="role")
    private String role;

    public User(){

    }

    public User(String ID, String password, String role){
        this.email=ID;
        this.password=password;
        this.role=role;
    }

    public String getEmail() {
        return email;
    }
    public void setEmail(String ID) {
        this.email= ID;
    }
    public String getPassword() {
        return password;
    }
    public void setPassword(String password) {
        this.password = password;
    }
    public String getRole() {
        return role;
    }
    public void setRole(String role) {
        this.role = role;
    }
    @Override
    public String toString() {
        return "User [useremail=" + email + ", password=" + password + ", role=" + role + "]";
    }
    
    
}

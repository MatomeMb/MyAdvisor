package com.capstoneproject.myadvisor.model;

public enum AppointmentStatus {
    AWAITING,
    DECLINED,
    ACCEPTED,
    DONE
}

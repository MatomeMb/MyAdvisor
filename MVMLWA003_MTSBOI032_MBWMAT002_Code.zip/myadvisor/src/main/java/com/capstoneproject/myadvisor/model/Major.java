package com.capstoneproject.myadvisor.model;
import java.util.List;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;

@Entity
@Table
public class Major {
    @Id
    @Column(name="majorname_id")
    private String majorname;


    @Column(name="department")
    private String department;
    
    @OneToMany(mappedBy="major")
    private List<CoreCourses> coreCourses;

    @OneToMany(mappedBy="major")
    private List<CommonElectives> commonelectives;

    public Major() {

    }
    public Major(String name, String code, List<CoreCourses> corecourses){
        this.majorname=name;
    //    this.coreCourses=corecourses;
    }
  
     public List<CoreCourses> getCoreCourses() {
        return coreCourses;
    }
    public void setCoreCourses(List<CoreCourses> coreCourses) {
        this.coreCourses = coreCourses;
    } 


    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    public String getMajorname() {
        return majorname;
    }

    public void setMajorname(String majorname) {
        this.majorname = majorname;
    }

    public List<CommonElectives> getCommonelectives() {
        return commonelectives;
    }

    public void setCommonelectives(List<CommonElectives> commonelectives) {
        this.commonelectives = commonelectives;
    }
    

}

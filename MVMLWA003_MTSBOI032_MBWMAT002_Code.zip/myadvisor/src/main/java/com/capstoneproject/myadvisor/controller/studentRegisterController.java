package com.capstoneproject.myadvisor.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.capstoneproject.myadvisor.model.Degree;
import com.capstoneproject.myadvisor.model.Major;
import com.capstoneproject.myadvisor.model.Student;
import com.capstoneproject.myadvisor.model.StudentMajors;
import com.capstoneproject.myadvisor.repository.MajorRepo;
import com.capstoneproject.myadvisor.repository.StudentMajorsRepo;
import com.capstoneproject.myadvisor.repository.UserRepo;
import com.capstoneproject.myadvisor.repository.studentRepo;


//import ch.qos.logback.core.model.Model;


@Controller
public class studentRegisterController {

    @Autowired
    private UserRepo userrepo;

    @Autowired
    private studentRepo studentrepo;

    @Autowired
    private MajorRepo majorrepo;

    private String studentemail;

    @Autowired
    private StudentMajorsRepo studentmajorsrepo;

    @PostMapping("/registration-form")
    public String studentSubmitRegistration(@RequestParam("email") String email, @RequestParam("password") String password, 
        @RequestParam("name") String name, @RequestParam("surname") String surname , @RequestParam("majorname") List<String> majorNames){

            Degree degree = new Degree();
            degree.setName("BSc");
            Student newstudent = new Student(email, password,"student", name, surname, degree);
            studentrepo.save(newstudent);

            List<String> studentmajornames = new ArrayList<>();
            
            for(String studentmajors: majorNames ){
                studentmajornames.add(studentmajors);
                System.out.println(studentmajors);
            }
             for(String majornames: studentmajornames){
                StudentMajors studentselectedmajors = new StudentMajors(majornames, newstudent);
                studentmajorsrepo.save(studentselectedmajors);
                System.out.println(majornames);
            }

            //newerstudent.get().setMajors(major);


        return "login";                
    }

    @GetMapping("/studentRegister")
    public String studentRegistion(Model model){
        List<Major> sciencemajors = majorrepo.findAll();
        List<String> sciencemajornames = new ArrayList<>();
        for(Major majorsscience: sciencemajors){
            System.out.println(majorsscience.getMajorname());
            sciencemajornames.add(majorsscience.getMajorname());
        }
        model.addAttribute("sciencemajornames", sciencemajornames);
        return "studentRegister";
    }

}

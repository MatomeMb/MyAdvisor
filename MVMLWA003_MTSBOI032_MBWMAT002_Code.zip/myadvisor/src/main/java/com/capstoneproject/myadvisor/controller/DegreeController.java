package com.capstoneproject.myadvisor.controller;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import com.capstoneproject.myadvisor.model.Degree;
import com.capstoneproject.myadvisor.repository.DegreeRepo;
import com.capstoneproject.myadvisor.service.DegreeService;



@Controller
public class DegreeController {
    @Autowired
    private DegreeRepo degreeRepo;
    
    @Autowired
    private DegreeService degreeService;

/*    @GetMapping("/systemAdminPage/users")
    public String getAllUsers(Model model) {
        List<User> users = userService.getAllUsers();
        model.addAttribute("users", users);

        return "users";
    }*/ 

    @PostMapping("/editDegree")
    public String editDegree(@ModelAttribute("degree") Degree updatedDegree, Model model) {
        // Retrieve the existing degree by name (assuming only one degree exists)
        List<Degree> users = degreeService.getAllDegree();
        Degree degree = users.get(0);  // Replace with actual name
        if (degree != null) {
            // Update the degree's details with the incoming form data
            degree.setTotalCredits(updatedDegree.getTotalCredits());
            degree.setScienceCredits(updatedDegree.getScienceCredits());
            degree.setLevel7Credits(updatedDegree.getLevel7Credits());
            
            // Save the updated degree
            degreeService.saveDegree(degree);
        }
        
        // Return to the admin page after saving
        return "redirect:/faculty_admin";
    }


    // GET request to load the form for adding a new user
    @GetMapping("/addDegreeForm")
    public String addDegreeForm(Model model) {
        // Initialize an empty User object for the form
        model.addAttribute("degree", new Degree());
        return "addDegree";  // Returns the Thymeleaf view for the form
    }
    
    @PostMapping("/addDegree")
    public String addDegree(@ModelAttribute Degree degree, Model model) {
        degreeRepo.save(degree);
        return "redirect:/faculty_admin";
    }
    

}
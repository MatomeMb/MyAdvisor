package com.capstoneproject.myadvisor.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capstoneproject.myadvisor.model.Degree;
import com.capstoneproject.myadvisor.repository.DegreeRepo;
@Service
public class DegreeService {

    @Autowired
    private DegreeRepo degreeRepo;

    public List<Degree> getAllDegree() {
        return degreeRepo.findAll();
    }

    public void saveDegree(Degree degree){
        degreeRepo.save(degree);
    }
}

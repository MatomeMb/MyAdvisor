package com.capstoneproject.myadvisor.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.capstoneproject.myadvisor.model.Major;

@Repository
public interface MajorRepo extends JpaRepository<Major, String> {
    List<Major> findByDepartment(String department);
}
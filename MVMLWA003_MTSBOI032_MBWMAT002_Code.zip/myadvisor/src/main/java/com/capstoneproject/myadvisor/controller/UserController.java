package com.capstoneproject.myadvisor.controller;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import com.capstoneproject.myadvisor.model.User;
import com.capstoneproject.myadvisor.repository.UserRepo;



@Controller
public class UserController {
    @Autowired
    private UserRepo userRepo;

/*    @GetMapping("/systemAdminPage/users")
    public String getAllUsers(Model model) {
        List<User> users = userService.getAllUsers();
        model.addAttribute("users", users);

        return "users";
    }*/ 

    // GET request to load the form for adding a new user
    @GetMapping("/addUserForm")
    public String addUserForm(Model model) {
        // Initialize an empty User object for the form
        model.addAttribute("user", new User());
        return "addUser";  // Returns the Thymeleaf view for the form
    }
    
    @PostMapping("/addUser")
    public String addUser(@ModelAttribute User user, Model model) {
        userRepo.save(user);
        return "redirect:/systemAdminPage";
    }

     @PostMapping("/deleteUser/{email}")
    public String deleteUser(@PathVariable("email") String email) {
        userRepo.deleteById(email);  
        return "redirect:/systemAdminPage";
    }
    

    

}
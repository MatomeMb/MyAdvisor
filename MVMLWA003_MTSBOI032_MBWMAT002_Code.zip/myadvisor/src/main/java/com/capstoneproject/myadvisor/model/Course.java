package com.capstoneproject.myadvisor.model;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
@Entity
@Table(name="COURSE")
public class Course {

    @Id
    private String courseCode;
//    @GeneratedValue(strategy = GenerationType.IDENTITY)
  //  private int id;

   // @Column(name="Course Code", unique=true, nullable=false)
   

    @Column(name="Course Name")
    private String courseName;

    @Column(name="NQF Credits")
    private int credits;

    @Column(name="NQF Level")
    private int nqflevel;
    
    @Column(name="Faculty")
    private String faculty;

    @Column(name="equivalent_courses")
    private String equivalence;

    @Column(name="prerequisites_course")
    private String prerequisites;
    
    public Course(){

    }

    
    public Course(String courseCode, String courseName, int credits, int nqflevel, String faculty, String equivalence) {
        this.courseCode = courseCode;
        this.courseName = courseName;
        this.credits = credits;
        this.nqflevel = nqflevel;
        this.faculty = faculty;
        this.equivalence = equivalence;
    }


    public Course(String courseCode, String courseName, int credits, int nqflevel, String faculty) {
        this.courseCode = courseCode;
        this.courseName = courseName;
        this.credits = credits;
        this.nqflevel = nqflevel;
        this.faculty = faculty;
    }
    

    public Course(String courseCode) {
        this.courseCode = courseCode;
    }

    public String getCourseCode() {
        return courseCode;
    }

    public void setCourseCode(String courseCode) {
        this.courseCode = courseCode;
    }

    public String getCourseName() {
        return courseName;
    }

    public void setCourseName(String courseName) {
        this.courseName = courseName;
    }

    public int getCredits() {
        return credits;
    }

    public void setCredits(int credits) {
        this.credits = credits;
    }



    public int getNqflevel() {
        return nqflevel;
    }

    public void setNqflevel(int nqflevel) {
        this.nqflevel = nqflevel;
    }

    public String getFaculty() {
        return faculty;
    }

    public void setFaculty(String faculty) {
        this.faculty = faculty;
    }

    public String getEquivalence() {
        return equivalence;
    }

    public void setEquivalence(String equivalence) {
        this.equivalence = equivalence;
    }

    public String getPrerequisites() {
        return prerequisites;
    }

    public void setPrerequisites(String prerequisites) {
        this.prerequisites = prerequisites;
    }
    

}

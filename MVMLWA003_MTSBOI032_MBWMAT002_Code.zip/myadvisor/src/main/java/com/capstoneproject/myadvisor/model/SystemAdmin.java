package com.capstoneproject.myadvisor.model;

public class SystemAdmin extends User {

}

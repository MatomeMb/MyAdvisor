package com.capstoneproject.myadvisor.model;

import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;


@Table
@Entity
public class Appointment {

    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    private int Id;

    @ManyToOne(fetch=FetchType.LAZY)
    @JoinColumn(name="student_email")
    private Student student;

    @ManyToOne(fetch=FetchType.LAZY)
    @JoinColumn(name = "advisor_email")
    private Advisor advisor;

    @ManyToOne(fetch=FetchType.LAZY)
    @JoinColumn(name="available_slot_id")
    private AvailableSlot availableSlot;

    @Column(name="meeting_start_time")
    private LocalTime meetingstarttime;

    @Column(name="meeting_date")
    private LocalDate meetingdate;

    @Enumerated(EnumType.STRING)
    @Column(name = "status")
    private AppointmentStatus status;

    @Column(name="reason")
    private String reason;

    public Appointment(){

    }
    public Appointment(int id, Student student, Advisor advisor, AvailableSlot availableSlot, LocalTime meetingstarttime, LocalDate meetingdate, String reason) {
        Id = id;
        this.student = student;
        this.advisor = advisor;
        this.availableSlot = availableSlot;
        this.meetingstarttime = meetingstarttime;
        this.meetingdate= meetingdate;
        this.reason=reason;
    }

    public int getId() {
        return Id;
    }

    public void setId(int id) {
        Id = id;
    }

    public Student getStudent() {
        return student;
    }

    public void setStudent(Student student) {
        this.student = student;
    }

    public Advisor getAdvisor() {
        return advisor;
    }

    public void setAdvisor(Advisor advisor) {
        this.advisor = advisor;
    }

    public AvailableSlot getAvailableSlot() {
        return availableSlot;
    }

    public void setAvailableSlot(AvailableSlot availableSlot) {
        this.availableSlot = availableSlot;
    }

    public LocalTime getMeetingstarttime() {
        return meetingstarttime;
    }

    public void setMeetingstarttime(LocalTime meetingstarttime) {
        this.meetingstarttime = meetingstarttime;
    }

    
    @Override
    public String toString() {
        DateTimeFormatter timeFormatter = DateTimeFormatter.ofPattern("hh:mm a"); 
        return "Student Email : "+ student.getEmail()+
        "\nName: "+ student.getName() + " " +student.getSurname()+
        "\nReason For Request: "+ reason+
        "\nDate: "+ meetingdate+
        "\nTime: "+meetingstarttime.format(timeFormatter)+
        "\nStatus: "+ status;
    } 

    
    public String getReason() {
        return reason;
    }

    public void setReason(String reason) {
        this.reason = reason;
    }

    public AppointmentStatus getStatus() {
        return status;
    }

    public void setStatus(AppointmentStatus status) {
        this.status = status;
    }

    public LocalDate getMeetingdate() {
        return meetingdate;
    }

    public void setMeetingdate(LocalDate meetingdate) {
        this.meetingdate = meetingdate;
    }
    

}

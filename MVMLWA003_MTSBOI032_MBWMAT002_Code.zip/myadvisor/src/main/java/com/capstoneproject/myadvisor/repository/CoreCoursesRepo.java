package com.capstoneproject.myadvisor.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.capstoneproject.myadvisor.model.CoreCourses;

@Repository
public interface CoreCoursesRepo extends JpaRepository<CoreCourses, Integer> {
    List<CoreCourses> findByMajorMajorname(String majorname_id);
    void deleteAllByCoursecode(String coursecode);
}
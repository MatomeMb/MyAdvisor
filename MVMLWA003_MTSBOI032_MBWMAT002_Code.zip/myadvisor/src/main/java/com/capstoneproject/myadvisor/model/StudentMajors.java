package com.capstoneproject.myadvisor.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Table(name="studentmajors")
@Entity
public class StudentMajors {

    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    private int Id;

    @Column(name="major_name")
    private String majorname;

    @ManyToOne
    @JoinColumn(name="student_email")
    private Student student;

    public StudentMajors(int id, String majorname, Student student) {
        Id = id;
        this.majorname = majorname;
        this.student = student;
    }
    public StudentMajors(){}
    

    public StudentMajors(String majorname, Student student) {
        this.majorname = majorname;
        this.student = student;
    }


    public int getId() {
        return Id;
    }

    public void setId(int id) {
        Id = id;
    }

    public String getMajorname() {
        return majorname;
    }

    public void setMajorname(String majorname) {
        this.majorname = majorname;
    }

    public Student getStudent() {
        return student;
    }

    public void setStudent(Student student) {
        this.student = student;
    }


    @Override
    public String toString() {
        return "StudentMajors [majorname=" + majorname + ", student=" + student + "]";
    }

    
}

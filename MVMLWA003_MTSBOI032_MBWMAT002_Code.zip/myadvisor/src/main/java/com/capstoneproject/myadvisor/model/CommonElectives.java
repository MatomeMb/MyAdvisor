package com.capstoneproject.myadvisor.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Table(name="commonelectives")
@Entity
public class CommonElectives {
    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    private int Id;

    private String coursecode;

    @ManyToOne
    @JoinColumn(name="majorname_id")
    private Major major;

    public int getId() {
        return Id;
    }

    public void setId(int Id) {
        this.Id = Id;
    }


    public Major getMajor() {
        return major;
    }

    public void setMajor(Major major) {
        this.major = major;
    }

    public String getCoursecode() {
        return coursecode;
    }

    public void setCoursecode(String coursecode) {
        this.coursecode = coursecode;
    }

}

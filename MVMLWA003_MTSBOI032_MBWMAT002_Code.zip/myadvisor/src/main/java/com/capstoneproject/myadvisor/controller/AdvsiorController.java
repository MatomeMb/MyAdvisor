
package com.capstoneproject.myadvisor.controller;

import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.capstoneproject.myadvisor.model.Advisor;
import com.capstoneproject.myadvisor.model.Appointment;
import com.capstoneproject.myadvisor.model.AppointmentStatus;
import com.capstoneproject.myadvisor.model.AvailableSlot;
import com.capstoneproject.myadvisor.model.CommonElectives;
import com.capstoneproject.myadvisor.model.CoreCourses;
import com.capstoneproject.myadvisor.model.Course;
import com.capstoneproject.myadvisor.model.Major;
import com.capstoneproject.myadvisor.model.User;
import com.capstoneproject.myadvisor.repository.AdvisorRepo;
import com.capstoneproject.myadvisor.repository.AppointmentRepo;
import com.capstoneproject.myadvisor.repository.AvailableSlotRepo;
import com.capstoneproject.myadvisor.repository.CommonElectivesRepo;
import com.capstoneproject.myadvisor.repository.CoreCoursesRepo;
import com.capstoneproject.myadvisor.repository.CourseRepo;
import com.capstoneproject.myadvisor.repository.MajorRepo;
import com.capstoneproject.myadvisor.repository.UserRepo;

@Controller
public class AdvsiorController {

    @Autowired
    private UserRepo userRepo;

    @Autowired(required=true)
    private AdvisorRepo advisorrepo;
    
    @Autowired
    private AvailableSlotRepo availableslotrepo;

    @Autowired
    private AppointmentRepo appointmentrepo;

    private String advisoremail;

    private Major majoradvisor;

    @Autowired
    private MajorRepo majorrepo;

    @Autowired
    private CoreCoursesRepo corecoursesrepo;

    @Autowired
    private CourseRepo courserepo;

    @Autowired
    private CommonElectivesRepo commonelectiverepo;

    @GetMapping("/Advisor")
    public String AdvisorPage(@RequestParam("email") String email, Model model) {
        advisoremail=email;
        Optional<User> userdata = userRepo.findById(email);
        Optional<Advisor> advisordata = advisorrepo.findById(email);
        List<AvailableSlot> advisortimes = availableslotrepo.findByAdvisorEmail(email);


        if(userdata.isPresent()){
            model.addAttribute("LoggedInUser", userdata.get());
            String names = advisordata.get().getName() + " " + advisordata.get().getSurname();
            model.addAttribute("advisornames", names);
          //  model.addAttribute("advisorsurname", advisordata.get().getSurname());
            model.addAttribute("advisoremail", userdata.get().getEmail());
            model.addAttribute("office",advisordata.get().getOffice());
            model.addAttribute("department", advisordata.get().getDepartment());
            model.addAttribute("faculty", advisordata.get().getFaculty());

            List<String> advisorslotsString = new ArrayList<>();

           // model.addAttribute("availabletimes", advisortimes);

            for(AvailableSlot advisorslot: advisortimes){
                advisorslotsString.add(advisorslot.toString());
            }

            model.addAttribute("availabletimes",advisorslotsString);

            //Appointment Requestss
    
            List<Appointment> acceptedAppointments = new ArrayList<>();
            List<Appointment> awaitingaAppointments = new ArrayList<>();
            List<Appointment> advisorAppointments = appointmentrepo.findByAdvisorEmail(email);

            for(Appointment advisorappointment: advisorAppointments){
                if(advisorappointment.getStatus().equals(AppointmentStatus.ACCEPTED)){
                    acceptedAppointments.add(advisorappointment);
                }
                else if(advisorappointment.getStatus().equals(AppointmentStatus.AWAITING)){
                    awaitingaAppointments.add(advisorappointment);   
                }
            }
            model.addAttribute("appointmentrequests",awaitingaAppointments);
            model.addAttribute("acceptedappointments",acceptedAppointments);

            //Majors info
            List<Major> advisormajor = majorrepo.findByDepartment(advisordata.get().getDepartment());
            List<String> majornameid = new ArrayList<>();
            List<String> coursescodes = new ArrayList<>();
            List<String> electivecodes = new ArrayList<>();

            for(Major majors: advisormajor){
                majoradvisor=majors;
                majornameid.add(majors.getMajorname());
            }
            for(String majorname: majornameid){
                List<CoreCourses> coreCourses = corecoursesrepo.findByMajorMajorname(majorname);
                List<CommonElectives> commonElectives = commonelectiverepo.findByMajorMajorname(majorname);

                for(CoreCourses corecourse: coreCourses){
                    coursescodes.add(corecourse.getCoursecode());
                    System.out.println(corecourse.getCoursecode());
                }

                for (CommonElectives commonelective: commonElectives) {
                    electivecodes.add(commonelective.getCoursecode());    
                }
            }
            
            List<Course> advisorcourses = new ArrayList<>();
            for(String courses: coursescodes) {
               // System.out.println(courses);
                Optional<Course> advisorcourse = courserepo.findById(courses);
                if(advisorcourse.isPresent()){
                    advisorcourses.add(advisorcourse.get());
                    System.out.println(advisorcourse.get().getCourseName());
                }
                
            }
            model.addAttribute("electives", electivecodes);
            model.addAttribute("courses",advisorcourses);
            model.addAttribute("course", new Course());
           



            return "Advisor";

        }


        return "Advisor";
    }
    @PostMapping("/submit-availability")
    public String AdvisorPageEditAvailability(@RequestParam("email") String email, @RequestParam("day") String day,
        @RequestParam("start-time") String startTime, @RequestParam("end-time") String endTime, Model model){
            Optional<User> userdata = userRepo.findById(email);
            Optional<Advisor> advisordata = advisorrepo.findById(email);
            boolean updated = false;
            LocalTime start_time = LocalTime.parse(startTime);
            LocalTime end_time = LocalTime.parse(endTime);

            if(advisordata.isPresent()){
                model.addAttribute("LoggedInUser", userdata.get());
                List<AvailableSlot> advisortimes = availableslotrepo.findByAdvisorEmail(email);
                for(AvailableSlot availableSlot: advisortimes){
                    if(availableSlot.getDay().equals(day)){
                        availableSlot.setStartTime(start_time);
                        availableSlot.setEndTime(end_time);
                        availableslotrepo.save(availableSlot);
                        updated=true;
                    }    
                }
                if(updated==false){
                    AvailableSlot newSlot = new AvailableSlot();
                    newSlot.setAdvisor(advisordata.get());
                    newSlot.setDay(day);
                    newSlot.setStartTime(start_time);
                    newSlot.setEndTime(end_time);
                    availableslotrepo.save(newSlot);


                }
                return "redirect:/Advisor?email=" + userdata.get().getEmail();

            }
            return "redirect:/Advisor?email=" + userdata.get().getEmail();
    }
    @PostMapping("/acceptordecline-appointment")
    public String AdvisorMeetingRequests(@RequestParam("appointmentId") int appointmentId, @RequestParam("notes") String notes, @RequestParam("action") String action){

        Optional<Appointment> appointment = appointmentrepo.findById(appointmentId);
        appointment.get().setReason(notes);
        if (action.equals("accept")){
            appointment.get().setStatus(AppointmentStatus.ACCEPTED);
        }
        else if(action.equals("decline")){
            appointment.get().setStatus(AppointmentStatus.DECLINED);
        }
        appointmentrepo.save((appointment.get()));
    
        return "redirect:/Advisor?email=" + advisoremail;
    }
    @PostMapping("/appointmentdone")
    public String appointmentsDone(@RequestParam("appointmentId") int appointmentId, @RequestParam("action") String action){
        Optional<Appointment> appointment = appointmentrepo.findById(appointmentId);
        appointment.get().setStatus(AppointmentStatus.DONE);
        appointmentrepo.save(appointment.get());
        return "redirect:/Advisor?email=" + advisoremail;
    }

    @PostMapping("/addCourse")
    public String addcourse(@ModelAttribute Course course, Model model){
        course.setFaculty("Science");
       
        Optional<Course> coursedb = courserepo.findById(course.getCourseCode());
        if(coursedb.isPresent()){
            coursedb.get().setCourseCode(course.getCourseCode());
            coursedb.get().setCourseName(course.getCourseName());
            coursedb.get().setCredits(course.getCredits());
            coursedb.get().setFaculty(course.getFaculty());
            coursedb.get().setNqflevel(course.getNqflevel());
            coursedb.get().setEquivalence(course.getEquivalence());
            coursedb.get().setPrerequisites(course.getPrerequisites());
            courserepo.save(coursedb.get());

        }
        else{
            CoreCourses addcore = new CoreCourses(course.getCourseCode(), majoradvisor);
            corecoursesrepo.save(addcore);
            courserepo.save(course);
        }
        return "redirect:/Advisor?email="+advisoremail;
    }
    @PostMapping("/add-elective")
    public String AddElective(@RequestParam("email") String email, @RequestParam("elective") String elective){
        Optional<Advisor> advisor = advisorrepo.findById(email);
        List<Major> advisormajor = majorrepo.findByDepartment(advisor.get().getDepartment());
        CommonElectives commonelective = new CommonElectives();
        commonelective.setCoursecode(elective);
        commonelective.setMajor(advisormajor.get(0));
        commonelectiverepo.save(commonelective);

        return "redirect:/Advisor?email="+email;
    }
    @jakarta.transaction.Transactional
    @PostMapping("/deleteCourse/{courseCode}")
    public String deleteCourse(@PathVariable("courseCode") String courseCode) {
     /*    List<CoreCourses> coreCourseses = corecoursesrepo.findAll();
        for(CoreCourses cc: coreCourseses){
            if (cc.getCoursecode().equals(courseCode)) {
                coreCourseses.remove(cc);
            }
        }*/
       // corecoursesrepo.deleteAllByCoursecode(courseCode);
        courserepo.deleteById(courseCode);
        return "redirect:/Advisor?email="+advisoremail;
    }

}

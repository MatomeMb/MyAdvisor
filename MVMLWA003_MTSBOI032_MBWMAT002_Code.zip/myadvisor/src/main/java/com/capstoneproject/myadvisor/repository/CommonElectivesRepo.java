package com.capstoneproject.myadvisor.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.capstoneproject.myadvisor.model.CommonElectives;

@Repository
public interface CommonElectivesRepo extends JpaRepository<CommonElectives, Integer> {
    List<CommonElectives> findByMajorMajorname(String majorname_id);
    void deleteAllByCoursecode(String coursecode);
}
package com.capstoneproject.myadvisor.controller;

import java.util.NoSuchElementException;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import com.capstoneproject.myadvisor.model.User;
import com.capstoneproject.myadvisor.repository.UserRepo;


@Controller
public class LoginController {
    @Autowired(required=true)
    private UserRepo userRepo;

    @GetMapping("/")
    public String Login(){
        return "login";
    }

    @PostMapping("/login-form")
    public String userDetails(@ModelAttribute User user, Model model){
        System.out.println(user.toString());

        String userId = user.getEmail();
        Optional<User> userdata = userRepo.findById(userId);

        if(userdata.isPresent()){
            if(user.getPassword().equals(userdata.get().getPassword())){
                model.addAttribute("LoggedInUser",userdata.get());
                System.out.println("Correct login details");
                switch (userdata.get().getRole()) {
                    case "student" -> {
                        return "redirect:/studentPage?email=" + userdata.get().getEmail();
                    }
                    case "advisor" -> {
                        return "redirect:/Advisor?email=" + userdata.get().getEmail();

                    }
                    case "faculty-admin" -> {
                        return "faculty_admin";
                    }
                    case "system-admin" -> {
                        return "systemAdminPage";
                    }
                    default -> {
                    }
                }
            }  
        }
        else{
            throw new NoSuchElementException("User not found with ID: " + userId);
        }
       return "login";


    }
}

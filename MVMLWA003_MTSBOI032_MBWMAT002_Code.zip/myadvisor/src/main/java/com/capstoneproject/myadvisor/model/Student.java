package com.capstoneproject.myadvisor.model;

import java.util.List;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.Inheritance;
import jakarta.persistence.InheritanceType;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;

@Entity
@Table(name="STUDENTS")
@Inheritance(strategy = InheritanceType.JOINED)
public class Student extends User {

    @Column
    private String name;

    private String surname;
    
    @ManyToOne
    @JoinColumn(name="degree_id")
    private Degree degree;

    //INSERT INTO student_majors (majorname_id, student_email) VALUES("Business Computing","lwazi@email")
    @OneToMany(mappedBy="student")
    private List<StudentMajors> studentMajors;

    @OneToMany(mappedBy="student", fetch=FetchType.LAZY)
    private List<Appointment> appointments;

    public Student(String email, String password, String role, String name, String surname, Degree degree, List<StudentMajors> majors, List<Course> completedCourses) {
        super(email, password, role);
        this.name = name;
        this.surname = surname;
        this.degree = degree;
        this.studentMajors=majors;
    }
    public Student(String email, String password, String role, String name, String surname, Degree degree){
        super(email, password, role);
        this.name = name;
        this.surname = surname;
        this.degree = degree;
    }

    public Student() {
        super();
    }

    public Degree getDegree() {
        return degree;
    }
    public String printDegree() {
       return degree.getName();
    }

    public void setDegree(Degree degree) {
        this.degree = degree;
    }

    
    
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSurname() {
        return surname;
    }

    public void setSurname(String surname) {
        this.surname = surname;
    }

    public List<Appointment> getAppointments() {
        return appointments;
    }

    public void setAppointments(List<Appointment> appointments) {
        this.appointments = appointments;
    }

  //  public List<StudentMajors> getStudentMajors() {
    //    return studentMajors;
  //  }

  //  public void setStudentMajors(List<StudentMajors> studentMajors) {
    //    this.studentMajors = studentMajors;
  //  }

    public List<StudentMajors> getStudentMajors() {
        return studentMajors;
    }

    public void setStudentMajors(List<StudentMajors> studentMajors) {
        this.studentMajors = studentMajors;
    }
}

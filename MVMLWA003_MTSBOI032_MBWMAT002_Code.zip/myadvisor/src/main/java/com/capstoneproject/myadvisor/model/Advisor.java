package com.capstoneproject.myadvisor.model;
import java.util.List;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.Inheritance;
import jakarta.persistence.InheritanceType;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;

@Entity
@Table(name = "Advisor")
@Inheritance(strategy = InheritanceType.JOINED)
public class Advisor extends User {

    
 
    @Override
    public String toString() {
        return "Advisor [name=" + name + ", surname=" + surname + ", office=" + office + ", department=" + department
                + ", faculty=" + faculty + ", getDepartment()=" + getDepartment() + "]";
    }

    @Column(name = "name")
    private String name;

    @Column(name="surname")
    private String surname;
     
    @Column(name="office")
    private String office;

    @Column(name = "department")
    private String department;
     
    @Column(name = "faculty")
    private String faculty;

    @OneToMany(mappedBy="advisor")
    private List<AvailableSlot> Availability;

    @OneToMany(mappedBy="advisor", fetch=FetchType.LAZY)
    private List<Appointment> appointments;

    public Advisor(){
        
    }


    public Advisor(String userID,  String password, String role, String department, String faculty, String name, String surname, String office, List<AvailableSlot> availability) {
        super(userID, password, role);
        this.name = name;
        this.surname=surname;
        this.office=office;
        this.department = department;
        this.faculty = faculty;
        this.Availability=availability;
    }
    public Advisor(String userID,  String password, String role, String department, String faculty, String name, String surname, String office) {
        super(userID, password, role);
        this.name = name;
        this.surname=surname;
        this.office=office;
        this.department = department;
        this.faculty = faculty;
    }

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    public void setfaculty(String faculty) {
        this.faculty = faculty;
    }

    public String getFaculty() {
        return faculty;
    }

    public void setAvailability(List<AvailableSlot> availableSlots) {
        this.Availability = availableSlots;
    }
    public List<AvailableSlot> getAvailability(){
        return Availability;
    }


    public void addAvailableSlot(AvailableSlot slot) {
        this.Availability.add(slot);
    }

    public void eddCourse(String courseID) {
        System.out.println(name + " has added: " + courseID);
    }

    public void uploadAdviceRecord(String studentID, String DocFile) {
        System.out.println(name + "has uploaded advice document to" + studentID);
    }

    public void approveCourse(String majorID) {
        System.out.println(name + " has updated major information for: " + majorID);

    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSurname() {
        return surname;
    }

    public void setSurname(String surname) {
        this.surname = surname;
    }

    public String getOffice() {
        return office;
    }

    public void setOffice(String office) {
        this.office = office;
    }

    public List<Appointment> getAppointments() {
        return appointments;
    }

    public void setAppointments(List<Appointment> appointments) {
        this.appointments = appointments;
    }
}
package com.capstoneproject.myadvisor.model;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Table
@Entity
public class Degree {
    @Id
    private String name;
    //@GeneratedValue(strategy= GenerationType.IDENTITY)
   // private int id;

    @Column(name="total credits")
    private int TotalCredits;

    @Column(name="Science Credits")
    private int ScienceCredits;

    @Column(name="Leve 7 credits")
    private int Level7Credits;
    
    public Degree(){

    }
    public Degree(String degreename, int totalcredits, int scicredits, int level7credits) {
        this.name=degreename;
        this.TotalCredits=totalcredits;
        this.ScienceCredits=scicredits;
        this.Level7Credits=level7credits;
        
    }
    public int getTotalCredits() {
        return TotalCredits;
    }
    public void setTotalCredits(int totalCredits) {
        TotalCredits = totalCredits;
    }
    public int getScienceCredits() {
        return ScienceCredits;
    }
    public void setScienceCredits(int scienceCredits) {
        ScienceCredits = scienceCredits;
    }
    public int getLevel7Credits() {
        return Level7Credits;
    }
    public void setLevel7Credits(int level7Credits) {
        Level7Credits = level7Credits;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
    
}

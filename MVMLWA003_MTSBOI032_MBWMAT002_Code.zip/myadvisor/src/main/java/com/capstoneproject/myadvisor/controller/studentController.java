package com.capstoneproject.myadvisor.controller;

import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.time.format.TextStyle;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.capstoneproject.myadvisor.model.Advisor;
import com.capstoneproject.myadvisor.model.Appointment;
import com.capstoneproject.myadvisor.model.AppointmentStatus;
import com.capstoneproject.myadvisor.model.AvailableSlot;
import com.capstoneproject.myadvisor.model.CommonElectives;
import com.capstoneproject.myadvisor.model.CoreCourses;
import com.capstoneproject.myadvisor.model.Course;
import com.capstoneproject.myadvisor.model.Degree;
import com.capstoneproject.myadvisor.model.Major;
import com.capstoneproject.myadvisor.model.Student;
import com.capstoneproject.myadvisor.model.StudentMajors;
import com.capstoneproject.myadvisor.model.User;
import com.capstoneproject.myadvisor.repository.AdvisorRepo;
import com.capstoneproject.myadvisor.repository.AppointmentRepo;
import com.capstoneproject.myadvisor.repository.AvailableSlotRepo;
import com.capstoneproject.myadvisor.repository.CommonElectivesRepo;
import com.capstoneproject.myadvisor.repository.CoreCoursesRepo;
import com.capstoneproject.myadvisor.repository.CourseRepo;
import com.capstoneproject.myadvisor.repository.DegreeRepo;
import com.capstoneproject.myadvisor.repository.MajorRepo;
import com.capstoneproject.myadvisor.repository.StudentMajorsRepo;
import com.capstoneproject.myadvisor.repository.UserRepo;
import com.capstoneproject.myadvisor.repository.studentRepo;

@Controller
public class studentController {

    @Autowired
    private UserRepo userRepo;

    @Autowired
    private CoreCoursesRepo corecoursesrepo;

    @Autowired(required=true)
    private studentRepo studentrepo;

    @Autowired
    private DegreeRepo degreeRepo;

    @Autowired
    private MajorRepo majorRepo;

    @Autowired
    private AdvisorRepo advisorrepo;

    @Autowired
    private AvailableSlotRepo availableslotrepo;

    private String studentemail;

    @Autowired
    private AppointmentRepo appointmentrepo;

    @Autowired
    private StudentMajorsRepo studentmajorsrepo;

    @Autowired
    private MajorRepo majorrepo;

    @Autowired
    private CourseRepo courseRepo;

    @Autowired
    private CommonElectivesRepo commonelectivesrepo;

    private List<Course> electives = new ArrayList<>();
    private List<Course> coursesPassed = new ArrayList<>();

    @GetMapping("/studentPage")
    public String studentPage(@RequestParam("email") String email, Model model){
        studentemail = email;
        Optional<User> userdata = userRepo.findById(email);
        Optional<Student> studentdata = studentrepo.findById(email);
        List<StudentMajors> majorsdata = studentmajorsrepo.findByStudentEmail(email);
        List<Major> studentmajorlist = new ArrayList<>();
        
        Optional<Degree> studentdegree = degreeRepo.findById("BSc");
        int totalcredits = studentdegree.get().getTotalCredits();
        int sciencecredits = studentdegree.get().getScienceCredits();
        int level7credits = studentdegree.get().getLevel7Credits();

        for(StudentMajors studentmajor: majorsdata){
            Optional<Major> majors = majorrepo.findById(studentmajor.getMajorname());
            studentmajorlist.add(majors.get());
            if(majors.get().getMajorname().equals("Business Computing") || majors.get().getMajorname().equals("Computer Engineering")){
                totalcredits=396;
            }
        }
        model.addAttribute("totalcredits", totalcredits);
        model.addAttribute("sciencecredits",sciencecredits);
        model.addAttribute("level7credits", level7credits);
        

        if (userdata.isPresent()){
            model.addAttribute("LoggedInUser", userdata.get());
            model.addAttribute("name", studentdata.get().getName());
            model.addAttribute("surname", studentdata.get().getSurname());
            List<String> studentdatamajors= new ArrayList<>();
            List<String> studentdepartment = new ArrayList<>();
            Map<String, List<Advisor>> departmentAdvisors = new HashMap<>();
            Map<String, List<AvailableSlot>> departmentAdvisorSlots = new HashMap<>();

            
            System.out.println("Student name: "+studentdata.get().getName());
            System.out.println("Student surname: "+studentdata.get().getSurname());
            System.out.println("Student degree: "+studentdata.get().printDegree());

            for(Major majordata :studentmajorlist){
                String department = majordata.getDepartment();
                System.out.println("Student majors are: " + majordata.getMajorname());
                studentdatamajors.add(majordata.getMajorname());
                studentdepartment.add(department);

                List<Advisor> advisors = advisorrepo.findByDepartment(department);
                departmentAdvisors.put(department, advisors);

                for (Advisor advisor : advisors) {
                String advisorEmail = advisor.getEmail();
                List<AvailableSlot> slots = availableslotrepo.findByAdvisorEmail(advisorEmail);
                departmentAdvisorSlots.put(advisorEmail, slots);
            }                

            }

            model.addAttribute("departmentAdvisors", departmentAdvisors);
            model.addAttribute("departmentAdvisorSlots", departmentAdvisorSlots);
            //model.addAttribute("departmentAdvisors", departmentAdvisors);
            String major1 = studentdatamajors.get(0);
            String major2 = studentdatamajors.get(1);

            String degreeprint = "no major";
            if(majorsdata.size()==2) {degreeprint = studentdata.get().printDegree()+" in "+ major1 +" and " +major2;}
            model.addAttribute("StudentDegree", degreeprint);

            //Upcoming Meetings
            List<Appointment> studentappointments = appointmentrepo.findByStudentEmail(email);
            model.addAttribute("upcomingappointments", studentappointments);

            //My Tutor
            List<CoreCourses> majoronecourse = corecoursesrepo.findByMajorMajorname(majorsdata.get(0).getMajorname());
            List<CoreCourses> majortwocourse = corecoursesrepo.findByMajorMajorname(majorsdata.get(1).getMajorname());
            List<CommonElectives> electives1 = commonelectivesrepo.findByMajorMajorname(majorsdata.get(0).getMajorname());
            System.out.println(electives1.get(0).getCoursecode()+"hereeeeeeeeeee");
            List<Course> electivecourses = new ArrayList<>();

            for(CommonElectives electivess: electives1){
                Optional<Course> electivecourse = courseRepo.findById(electivess.getCoursecode());
                if(electivecourse.isPresent()){
                    System.out.println(electivecourse.get().getCourseName());
                    electivecourses.add(electivecourse.get());
                }
            }
            System.out.println(electivecourses.get(0).getCourseCode());

            model.addAttribute("electivescourses", electivecourses);

            model.addAttribute("majorname1", major1);
            model.addAttribute("majorname2",major2);
            model.addAttribute("firstcore", majoronecourse);
            model.addAttribute("secondcore", majortwocourse);

            model.addAttribute("course", new Course());
           // for(Course electivess : electives) {
           //     System.out.println(electivess.getCourseCode());
           // }
            model.addAttribute("electives",electives);

        //    System.out.println(totalcredits+" "+ " " +sciencecredits+ " "+ level7credits);
            int totalremaining=totalcredits;
            int scienceremaining=sciencecredits;
            int level7remaining=level7credits;
            
            for(Course passedCourse: coursesPassed){
                int coursecredits = passedCourse.getCredits();
                totalremaining = totalremaining-coursecredits;
                if(passedCourse.getFaculty().equals("Science")){
                    scienceremaining = scienceremaining-coursecredits; 
                }
                if(passedCourse.getNqflevel() == 7){
                    level7remaining = level7remaining-coursecredits;
                }

        
            }
            if(totalremaining<0){
                totalremaining=0;
            }
            if(scienceremaining<0){
                scienceremaining=0;
            }
            if (level7remaining<0) {
                level7remaining=0;
            }
            model.addAttribute("totalremaining", totalremaining);
            model.addAttribute("scienceremaining",scienceremaining);
            model.addAttribute("level7remaining",level7remaining);
            model.addAttribute("coursespassed", coursesPassed);
            


            



            return "studentPage";
            

        }
        else{
            throw new NoSuchElementException("Student not found with ID: " + email);

        }
        
    }
    
    @PostMapping("/make-booking")
    public String StudentMakeAppointment(@RequestParam("studentEmail") String studentEmail, @RequestParam("advisorEmail") String advisorEmail, @RequestParam("appointment-date") String date,
         @RequestParam("meetingTime") String meetingTime, @RequestParam("reason") String reason){
            Optional<Advisor> advisordata = advisorrepo.findById(advisorEmail);
            Optional<Student> studentdata = studentrepo.findById(studentEmail);

            LocalTime start_time = LocalTime.parse(meetingTime);
            LocalDate meeting_date = LocalDate.parse(date, DateTimeFormatter.ISO_LOCAL_DATE);

            Appointment appointment = new Appointment();
            appointment.setAdvisor(advisordata.get());
            appointment.setStudent(studentdata.get());
            appointment.setMeetingstarttime(start_time);
            appointment.setMeetingdate(meeting_date);
            appointment.setReason(reason);
            System.out.println(reason);

            String meeting_day = meeting_date.getDayOfWeek().getDisplayName(TextStyle.FULL, Locale.ENGLISH);
            List<AvailableSlot> advisortimes = availableslotrepo.findByAdvisorEmail(advisorEmail);

            for(AvailableSlot availableSlot: advisortimes){
                if(availableSlot.getDay().equals(meeting_day)){
                    appointment.setAvailableSlot(availableSlot);       
                    break;
                }    
            }
            appointment.setStatus(AppointmentStatus.AWAITING);
            appointmentrepo.save(appointment);

            return "redirect:/studentPage?email="+ studentdata.get().getEmail();
    }

    @PostMapping("/addelective")
    public String AddElectives(@RequestParam("email") String email, @RequestParam("elective") String elective, Model model){
        Optional<Course> electivecourse = courseRepo.findById(elective);
        if(electivecourse.isPresent()){
            System.out.println(electivecourse.get().getCourseName());
            electives.add(electivecourse.get());
            coursesPassed.add(electivecourse.get());
        }
        else{
            System.out.println("No course found for "+ elective);
        }
        
        return "redirect:/studentPage?email="+ email;
    }

    @PostMapping("/addcoursespassed")
    public String AddCoursesPassed(@RequestParam("email") String email, @RequestParam List<String> firstCoreCourses, @RequestParam List<String> secondCoreCourses){
        for(String list1: firstCoreCourses) {
            System.out.println(list1);
            Optional<Course> corecourse = courseRepo.findById(list1);
            coursesPassed.add(corecourse.get());
        }
        for(String list2: secondCoreCourses){
            Optional<Course> corecourse2 = courseRepo.findById(list2);
            coursesPassed.add(corecourse2.get());
            System.out.println(list2);
        }
        return "redirect:/studentPage?email="+email;
    }
    
}

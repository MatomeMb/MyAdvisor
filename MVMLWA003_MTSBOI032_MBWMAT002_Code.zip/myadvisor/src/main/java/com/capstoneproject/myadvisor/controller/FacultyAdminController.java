package com.capstoneproject.myadvisor.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.capstoneproject.myadvisor.model.Advisor;
import com.capstoneproject.myadvisor.model.Degree;
import com.capstoneproject.myadvisor.service.AdvisorService;
import com.capstoneproject.myadvisor.service.DegreeService;

@Controller
public class FacultyAdminController {
    
    @Autowired
    private DegreeService degreeService;

    @Autowired
    private AdvisorService advisorService;

    @GetMapping("/faculty_admin")
    public String FacultyAdminPage(Model model) {
        List<Degree> degrees = degreeService.getAllDegree();
        List<Advisor> advisors = advisorService.getAllAdvisors();
        //model.addAttribute("users", degrees);

        
            model.addAttribute("total_credits", degrees.get(0).getTotalCredits());
            model.addAttribute("Science_Credits", degrees.get(0).getScienceCredits());
            model.addAttribute("Level_7_credits", degrees.get(0).getLevel7Credits());
            model.addAttribute("degree", new Degree());
            model.addAttribute("advisors", advisors);
           // System.out.println("Student name: "+studentdata.get().getName());
          //  System.out.println("Student surname: "+studentdata.get().getSurname());

            
        
        return "faculty_admin";

    
    }
    

    @PostMapping("/addAdvisor")
    public String addAdvisor(
        @RequestParam("email") String email,
        @RequestParam("password") String password,
        @RequestParam("department") String department,
        @RequestParam("name") String name,
        @RequestParam("surname") String surname,
        @RequestParam("office") String office,
        Model model) {
    
    // Create a new advisor object
        Advisor newAdvisor = new Advisor(email, password, "advisor", department, "science", name, surname,  office);    
    // Save the new advisor
        advisorService.saveAdvisor(newAdvisor);

    // Add attributes for rendering the updated view
        List<Degree> degrees = degreeService.getAllDegree();
        List<Advisor> advisors = advisorService.getAllAdvisors();

    // Add updated attributes to the model
        model.addAttribute("total_credits", degrees.get(0).getTotalCredits());
        model.addAttribute("Science_Credits", degrees.get(0).getScienceCredits());
        model.addAttribute("Level_7_credits", degrees.get(0).getLevel7Credits());
        model.addAttribute("degree", new Degree());
        model.addAttribute("advisors", advisors);

        return "faculty_admin";
    }

    

    @PostMapping("/deleteAdvisor")
    public String deleteAdvisor(@RequestParam("email") String email, Model model) {
        // Delete the advisor by email
        advisorService.deleteAdvisorByEmail(email);

        // After deletion, return to the faculty admin page with updated list
        List<Advisor> advisors = advisorService.getAllAdvisors();
        List<Degree> degrees = degreeService.getAllDegree();
        model.addAttribute("total_credits", degrees.get(0).getTotalCredits());
        model.addAttribute("Science_Credits", degrees.get(0).getScienceCredits());
        model.addAttribute("Level_7_credits", degrees.get(0).getLevel7Credits());
        model.addAttribute("degree", new Degree());
        
        model.addAttribute("advisors", advisors);
        return "faculty_admin"; // Redirect or return the view as needed
    }


}
package com.capstoneproject.myadvisor.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.capstoneproject.myadvisor.model.StudentMajors;
@Repository
public interface StudentMajorsRepo extends JpaRepository<StudentMajors, Integer> {
        List<StudentMajors> findByStudentEmail(String studentEmail);   

}

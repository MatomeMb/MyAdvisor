package com.capstoneproject.myadvisor.service;

//import org.hibernate.mapping.List;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capstoneproject.myadvisor.model.Advisor;
import com.capstoneproject.myadvisor.repository.AdvisorRepo;

@Service
public class AdvisorService {
    @Autowired
    private AdvisorRepo advisorRepo;

    public List<Advisor> getAllAdvisors(){
        return advisorRepo.findAll();
    }

    public void saveAdvisor(Advisor advisor){
        advisorRepo.save(advisor);
    }
    public Advisor getCourseByDepartment(String email){
        return advisorRepo.findById(email).get();
    }

    public void deleteAdvisorByEmail(String email){
        advisorRepo.deleteById(email);
    }
}
package com.capstoneproject.myadvisor;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MyadvisorApplication {

	public static void main(String[] args) {
		SpringApplication.run(MyadvisorApplication.class, args);
	}

}

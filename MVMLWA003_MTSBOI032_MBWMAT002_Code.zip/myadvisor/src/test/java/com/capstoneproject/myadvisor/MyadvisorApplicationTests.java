package com.capstoneproject.myadvisor;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MyadvisorApplicationTests {

	@Test
	void contextLoads() {
	}

}
